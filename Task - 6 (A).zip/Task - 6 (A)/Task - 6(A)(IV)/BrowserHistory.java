import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

public class BrowserHistory {
    private Deque<String> backStack = new ArrayDeque<>();
    private Deque<String> forwardStack = new ArrayDeque<>();
    private String currentPage = "Home";

    // Add a new page to the history
    public void visitPage(String url) {
        if (currentPage != null) {
            backStack.push(currentPage);
        }
        currentPage = url;
        forwardStack.clear();
        System.out.println("Visited: " + currentPage);
    }

    // Go back to the previous page
    public void goBack() {
        if (backStack.isEmpty()) {
            System.out.println("No previous page to go back to.");
            return;
        }
        forwardStack.push(currentPage);
        currentPage = backStack.pop();
        System.out.println("Went back to: " + currentPage);
    }

    // Go forward to the next page
    public void goForward() {
        if (forwardStack.isEmpty()) {
            System.out.println("No forward page to go to.");
            return;
        }
        backStack.push(currentPage);
        currentPage = forwardStack.pop();
        System.out.println("Went forward to: " + currentPage);
    }

    // Display the current page
    public void displayCurrentPage() {
        System.out.println("Current Page: " + currentPage);
    }

    public static void main(String[] args) {
        BrowserHistory browserHistory = new BrowserHistory();
        Scanner scanner = new Scanner(System.in);
        String command;
        
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Visit a new page");
            System.out.println("2. Go back");
            System.out.println("3. Go forward");
            System.out.println("4. Display current page");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            command = scanner.nextLine();

            switch (command) {
                case "1":
                    System.out.print("Enter URL: ");
                    String url = scanner.nextLine();
                    browserHistory.visitPage(url);
                    break;
                case "2":
                    browserHistory.goBack();
                    break;
                case "3":
                    browserHistory.goForward();
                    break;
                case "4":
                    browserHistory.displayCurrentPage();
                    break;
                case "5":
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}