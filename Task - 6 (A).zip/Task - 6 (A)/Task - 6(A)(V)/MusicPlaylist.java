import java.util.LinkedList;
import java.util.Scanner;

public class MusicPlaylist {
    private LinkedList<String> playlist = new LinkedList<>();

    // Add a song to the playlist
    public void addSong(String song) {
        playlist.add(song);
        System.out.println("Added: " + song);
    }

    // Remove a song by name
    public void removeSong(String song) {
        if (playlist.remove(song)) {
            System.out.println("Removed: " + song);
        } else {
            System.out.println("Song not found in the playlist.");
        }
    }

    // Move a song to a different position
    public void moveSong(String song, int newPosition) {
        if (!playlist.contains(song)) {
            System.out.println("Song not found in the playlist.");
            return;
        }
        if (newPosition < 0 || newPosition >= playlist.size()) {
            System.out.println("Invalid position.");
            return;
        }
        playlist.remove(song);
        playlist.add(newPosition, song);
        System.out.println("Moved: " + song + " to position " + (newPosition + 1));
    }

    // Display the playlist
    public void displayPlaylist() {
        System.out.println("\nCurrent Playlist:");
        int position = 1;
        for (String song : playlist) {
            System.out.println(position + ". " + song);
            position++;
        }
    }

    public static void main(String[] args) {
        MusicPlaylist musicPlaylist = new MusicPlaylist();
        Scanner scanner = new Scanner(System.in);
        String command;

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add a song to the playlist");
            System.out.println("2. Remove a song by name");
            System.out.println("3. Move a song to a different position");
            System.out.println("4. Display the playlist");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            command = scanner.nextLine();

            switch (command) {
                case "1":
                    System.out.print("Enter song name: ");
                    String songToAdd = scanner.nextLine();
                    musicPlaylist.addSong(songToAdd);
                    break;
                case "2":
                    System.out.print("Enter song name to remove: ");
                    String songToRemove = scanner.nextLine();
                    musicPlaylist.removeSong(songToRemove);
                    break;
                case "3":
                    System.out.print("Enter song name to move: ");
                    String songToMove = scanner.nextLine();
                    System.out.print("Enter new position (starting from 1): ");
                    int newPosition = scanner.nextInt() - 1; // -1 because LinkedList is 0-indexed
                    scanner.nextLine(); // Consume newline
                    musicPlaylist.moveSong(songToMove, newPosition);
                    break;
                case "4":
                    musicPlaylist.displayPlaylist();
                    break;
                case "5":
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
