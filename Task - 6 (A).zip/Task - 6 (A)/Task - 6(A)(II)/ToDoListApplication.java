package todolist;
 import java.util.ArrayList;
 import java.util.List;
 import java.util.Scanner;
 public class ToDoListApplication {
 private List<String> toDoList = new ArrayList<>();
    public void addTask(String task) {
        toDoList.add(task);
        System.out.println("Task added: " + task);
    }
    public void updateTask(int index, String updatedTask) {
        if (index >= 0 && index < toDoList.size()) {
            toDoList.set(index, updatedTask);
            System.out.println("Task updated at position " + (index + 1) + ": " + updatedTask);
        } else {
            System.out.println("Invalid task index.");
        }
    }
    public void removeTask(int index) {
        if (index >= 0 && index < toDoList.size()) {
            String removedTask = toDoList.remove(index);
            System.out.println("Task removed: " + removedTask);
        } else {
            System.out.println("Invalid task index.");
        }
    }
    public void displayTasks() {
        if (toDoList.isEmpty()) {
            System.out.println("To-do list is empty.");
        } else {
            System.out.println("To-do list:");
            for (int i = 0; i < toDoList.size(); i++) {
                System.out.println((i + 1) + ". " + toDoList.get(i));
            }
        }
    }
    public static void main(String[] args) {
        ToDoListApplication toDoListApp = new ToDoListApplication();
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nTo-Do List Application");
            System.out.println("1. Add Task");
            System.out.println("2. Update Task");
            System.out.println("3. Remove Task");
            System.out.println("4. Display All Tasks");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("Enter task description: ");
                    String newTask = scanner.nextLine();
                    toDoListApp.addTask(newTask);
                    break;
                case 2:
                    System.out.print("Enter task number to update: ");
                    int updateIndex = scanner.nextInt() - 1;
                    scanner.nextLine();
                    System.out.print("Enter new task description: ");
                    String updatedTask = scanner.nextLine();
                    toDoListApp.updateTask(updateIndex, updatedTask);
                    break;
                case 3:
                    System.out.print("Enter task number to remove: ");
                    int removeIndex = scanner.nextInt() - 1;
                    toDoListApp.removeTask(removeIndex);
                    break;
                case 4:
                    toDoListApp.displayTasks();
                    break;
                case 5:
                    System.out.println("Exiting To-Do List Application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
        scanner.close();
    }
 }