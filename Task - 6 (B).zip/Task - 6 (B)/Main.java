package generics;
 public interface Arrayoperations <T extends Comparable<T>>{
 T findMax(T[] array); 
    T findMin(T[] array);
 }
 package generics;
 public class ArrayProcessor<T extends Comparable<T>> implements Arrayoperations<T> {
    public T findMax(T[] array) {
        if (array == null || array.length == 0) return null; 
        T max = array[0];
        for (T element : array) {
            if (element.compareTo(max) > 0) {
                max = element;
            }
        }
        return max;
    }
    public T findMin(T[] array) {
        if (array == null || array.length == 0) return null; 
        T min = array[0];
        for (T element : array) {
            if (element.compareTo(min) < 0) {
                min = element;
            }
        }
        return min;
    }
 }
 package generics;
 public class Main {
 public static void main(String[] args) {
        ArrayProcessor<Integer> intProcessor = new ArrayProcessor<>();
        ArrayProcessor<String> stringProcessor = new ArrayProcessor<>();
        ArrayProcessor<Character> charProcessor = new ArrayProcessor<>();
        ArrayProcessor<Float> floatProcessor = new ArrayProcessor<>();
        Integer[] intArray = {3, 9, 2, 4, 7, 1};
        System.out.println("Integer Array:");
        System.out.println("Max: " + intProcessor.findMax(intArray));
        System.out.println("Min: " + intProcessor.findMin(intArray));
        String[] stringArray = {"apple", "banana", "orange", "pear", "grape"};
        System.out.println("\nString Array:");
        System.out.println("Max: " + stringProcessor.findMax(stringArray));
        System.out.println("Min: " + stringProcessor.findMin(stringArray));
        Character[] charArray = {'x', 'a', 'm', 'e', 'z'};
        System.out.println("\nCharacter Array:");
        System.out.println("Max: " + charProcessor.findMax(charArray));
        System.out.println("Min: " + charProcessor.findMin(charArray));
        Float[] floatArray = {2.4f, 5.7f, 1.1f, 9.3f, 3.8f};
        System.out.println("\nFloat Array:");
        System.out.println("Max: " + floatProcessor.findMax(floatArray));
        System.out.println("Min: " + floatProcessor.findMin(floatArray));
    }
 }